"""
auteurs : Arthur Le Menn, Matis Chabanat
groupe : TD1 | TP1
"""

import pyodbc

#Connexion à la base de donnée
conn=pyodbc.connect('DSN=BD_Le-Menn_Lakartxela')

cursor = conn.cursor()

SQLRequest = ("""SELECT COUNT(*) FROM MAccident 
              JOIN MDate ON MAccident.date_id = MDate.date_id
              WHERE YEAR(DATE(DateFormatStandard)) = 1992
              GROUP BY MONTH(DATE(DateFormatStandard))""")
cursor.execute(SQLRequest)

#Création d'un tableau mois
Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet",
            "Aout", "Septembre", "Octobre", "Novembre", "Decembre"]

#Création d'un fonction qui permet par rapport à l'indice du mois, de retourner la saison
def saisonFinder(moisIndice):
    if moisIndice < 3:
        return "Hiver"
    elif moisIndice < 6:
        return "Printemps"
    elif moisIndice < 9:
        return "Eté"
    elif moisIndice < 12:
        return "Automne"
    else:
        "Mois incorrect"
    

#Afficher le nombre d'accident sur une annee
def request1(annee):
    SQLRequest = ("""SELECT COUNT(*) FROM MAccident 
              JOIN MDate ON MAccident.date_id = MDate.date_id
              WHERE YEAR(DATE(DateFormatStandard)) = ?
              GROUP BY MONTH(DATE(DateFormatStandard));""")
    param = (str(annee))
    cursor.execute(SQLRequest, param)
    i = 0
    Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre",
            "Octobre", "Novembre", "Decembre"]
    Saison = {}
    #On remplit le dictionnaire résultat avec le résultat de la requête
    for row in cursor.fetchall():
        if saisonFinder(i) not in Saison.keys():
            Saison[saisonFinder(i)] = row[0]
        else:
            Saison[saisonFinder(i)] += row[0]
        i += 1
    return Saison

#Afficher le nombre d'accidents de gravite 3 par saison
def request2(annee):
    SQLRequest = ("""SELECT COUNT(*) FROM MAccident 
              JOIN MDate ON MAccident.date_id = MDate.date_id
              WHERE YEAR(DATE(DateFormatStandard)) = ? AND gravite = 3
              GROUP BY MONTH(DATE(DateFormatStandard));""")
    param = (str(annee))
    cursor.execute(SQLRequest, param)
    i = 0
    Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre",
            "Octobre", "Novembre", "Decembre"]
    Saison = {}
    #On remplit le dictionnaire résultat avec le résultat de la requête
    for row in cursor.fetchall():
        if saisonFinder(i) not in Saison.keys():
            Saison[saisonFinder(i)] = row[0]
        else:
            Saison[saisonFinder(i)] += row[0]
        i += 1
    return Saison

def nameToIndice(nom, table):
    for i in range(len(table)):
        if nom == table[i]:
            return i

def indiceToName(ind, table):
    return table[ind]
    
        
def trouverNbMax(liste, nbMax):
    copie = liste
    listeIndMax = []
    for i in range(nbMax):
        maxi = -999
        indMaxi = 0
        for y in range(len(copie)):
            if copie[y] > maxi and y not in listeIndMax:
                indMaxi = y
                maxi = copie[y]
        listeIndMax.append(indMaxi)
    return listeIndMax
                


def request3(annee, nomMois):
    #Tout d'abord on va remplir le tableau Implication qui contiendra tout les libellé des implications
    Implication = []
    SQLRequest = ("""
                  SELECT MImplique.libelle FROM MImplique
                  GROUP BY MImplique.libelle""")
    cursor.execute(SQLRequest)
    for row in cursor.fetchall():
        Implication.append(row[0])
                  
    #On execute maintenant la requête principal
    SQLRequest = ("""
                  SELECT MImplique.libelle, MONTH(MDate.DateFormatStandard) FROM MAccident
                    JOIN MImplique ON MAccident.impliq_id = MImplique.code
                    JOIN MDate ON MAccident.date_id = MDate.date_id
                    WHERE YEAR(MDate.DateFormatStandard) = ?
                  """)
    param = (str(annee))
    cursor.execute(SQLRequest, param)
    i = 0
    Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet",
            "Aout", "Septembre", "Octobre", "Novembre", "Decembre"]
    MoisDico = {}
    #On remplie le dictionnaire résultat avec les données
    for row in cursor.fetchall():
        if Mois[row[1]-1] not in MoisDico.keys():
            numImpli = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            MoisDico[Mois[row[1]-1]] = numImpli
            MoisDico[Mois[row[1]-1]][nameToIndice(str(row[0]), Implication)] += 1
            
        else:
            MoisDico[Mois[row[1]-1]][nameToIndice(str(row[0]), Implication)] += 1
    tabRes = []
    #On trouve les 3 max et on les range dans l'ordre dans le tableau tabRes
    tabMax = trouverNbMax(MoisDico[nomMois], 3)
    for i in range(len(tabMax)):
        tabRes.append((indiceToName(tabMax[i], Implication), MoisDico[nomMois][tabMax[i]]))
    return tabRes

def request4(annee, nomMois):
    #On remplit un tableau Cause avec toutes les causes
    Cause = []
    SQLRequest = ("""
                  SELECT MCause.libelle FROM MCause
                  GROUP BY MCause.libelle""")
    cursor.execute(SQLRequest)
    for row in cursor.fetchall():
        Cause.append(row[0])
    #On passe maintenant à la requête principal
    SQLRequest = ("""
                  SELECT MCause.libelle, MONTH(MDate.DateFormatStandard) FROM MAccident
                    JOIN MCause ON MAccident.cause_id = MCause.Cause
                    JOIN MDate ON MAccident.date_id = MDate.date_id
                    WHERE YEAR(MDate.DateFormatStandard) = ?
                  """)
    param = (str(annee))
    cursor.execute(SQLRequest, param)
    i = 0
    Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet",
            "Aout", "Septembre", "Octobre", "Novembre", "Decembre"]
    MoisDico = {}
    #On remplit le dictionnaire résultat avec les données
    for row in cursor.fetchall():
        if Mois[row[1]-1] not in MoisDico.keys():
            numCause = [0]*len(Cause)
            MoisDico[Mois[row[1]-1]] = numCause
            MoisDico[Mois[row[1]-1]][nameToIndice(str(row[0]), Cause)] += 1
        else:
            MoisDico[Mois[row[1]-1]][nameToIndice(str(row[0]), Cause)] += 1
    
    tabRes = []
    #On trouve les 3 max et on les range dans l'ordre dans le tableau tabRes
    tabMax = trouverNbMax(MoisDico[nomMois], 3)
    for i in range(len(tabMax)):
        tabRes.append((indiceToName(tabMax[i], Cause), MoisDico[nomMois][tabMax[i]]))
    return tabRes
    

    
def request5(annee):
    jours = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"]
    SQLRequest = ("""
                  SELECT COUNT(*) FROM MAccident
                  JOIN MDate ON MAccident.date_id = MDate.date_id
                  WHERE YEAR(MDate.DateFormatStandard) = ?
                  GROUP BY DAYOFWEEK(MDate.DateFormatStandard)
                  """)
    param = (str(annee))
    cursor.execute(SQLRequest, param)
    i = 0
    tabRes = {}
    for row in cursor.fetchall():
        if jours[i] not in tabRes.keys():
            tabRes[jours[i]] = row[0]
        else:
            tabRes[jours[i]] += row[0]
        i += 1
    return tabRes
        
#Application console
Mois = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet",
            "Aout", "Septembre", "Octobre", "Novembre", "Decembre"]
def appliConsole():
    #Affichage du menu
    print("Bienvenue dans l'application de Matis et Arthur")
    print("_______________________________________________")
    print("                  Menu                         ")
    print("1. Nombre d’accidents par saison")
    print("2. Nombre d'accidents très graves (Gravité 3) par saison")
    print("3. Le top 3 des types d’impliqué avec le plus d’accidents par mois")
    print("4. Le top 3 des causes qui reviennent le plus par mois")
    print("5. Nombre d'accidents par jours par saison")
    print("6. Quitter")
    print("_______________________________________________")
    #Saisie verif menu
    while True:
        inputUser = input()
        if(0 < int(inputUser) < 7):
            break
        else:
            print("Veuillez rentrer un nombre valide (entre 1 et 6)")
    if inputUser == "1":
        #requête 1
        inputAnnee = input("Veuillez rentrer une année entre 1984 et 1998 --> ")
        dico =request1(int(inputAnnee))
        print(inputAnnee)
        print("_____________")
        for i in dico.keys():
            print(i + " : " + str(dico[i]))

    elif inputUser == "2":
        #requête 2
        inputAnnee = input("Veuillez rentrer une année entre 1984 et 1998 --> ")
        dico =request2(int(inputAnnee))
        print(inputAnnee)
        print("_____________")
        for i in dico.keys():
            print(i + " : " + str(dico[i]))
        
    elif inputUser == "3":
        #requête 3
        inputAnnee = input("Veuillez rentrer une année entre 1984 et 1998 --> ")
        print("")
        for i in range(len(Mois)):
            print(str(i+1) + ". " + Mois[i])
        print("")
        inputMois = input("Veuillez rentrer le numéro d'un mois --> ")
        tabRes = request3(int(inputAnnee), Mois[int(inputMois)-1])
        print("")
        print(inputAnnee)
        print("--------------")
        print(Mois[int(inputMois)-1])
        print("--------------")
        for i in range(len(tabRes)):
            print(str(i+1) + " : " + str(tabRes[i][0]) + " --> " + str(tabRes[i][1]))
        
    elif inputUser == "4":
        #requête 4
        inputAnnee = input("Veuillez rentrer une année entre 1984 et 1998 --> ")
        print("")
        for i in range(len(Mois)):
            print(str(i+1) + ". " + Mois[i])
        print("")
        inputMois = input("Veuillez rentrer le numero d'un mois  --> ")
        tabRes = request4(int(inputAnnee), Mois[int(inputMois)-1])
        print("")
        print(inputAnnee)
        print("--------------")
        print(Mois[int(inputMois)-1])
        print("--------------")
        for i in range(len(tabRes)):
            print(str(i+1) + " : " + str(tabRes[i][0]) + " --> " + str(tabRes[i][1]))
        
    elif inputUser == "5":
        #requête 5
        inputAnnee = input("Veuillez rentrer une année entre 1984 et 1998 --> ")
        dico =request5(int(inputAnnee))
        print("")
        print(inputAnnee)
        print("_____________")
        for i in dico.keys():
            print(i + " : " + str(dico[i]))
    else:
        #L'user veut quitter
        print("Aurevoir")
    