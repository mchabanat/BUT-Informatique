package com.example.tp1_restaurant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class ParametrageActivity extends AppCompatActivity {
    // Attributs
    private Button b_retour;
    private Button b_ajouter;
    private Button b_enregistrer;
    private Button b_supprimer;
    private RadioGroup rg_types;
    private RadioButton br_entree;
    private RadioButton br_plat;
    private RadioButton br_dessert;
    private EditText et_intitule;
    private EditText et_modifier;
    private Spinner sp_modifEntree;
    private Spinner sp_modifPlat;
    private Spinner sp_modifDessert;
    private Spinner sp_supprEntree;
    private Spinner sp_supprPlat;
    private Spinner sp_supprDessert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parametrage);

        // Recup des id
        b_retour = findViewById(R.id.b_retour);
        b_ajouter = findViewById(R.id.b_ajouter);
        b_enregistrer = findViewById(R.id.b_enregistrer);
        b_supprimer = findViewById(R.id.b_supprimer);
        rg_types = findViewById(R.id.rg_types);
        br_entree = findViewById(R.id.br_entree);
        br_plat = findViewById(R.id.br_plat);
        br_dessert = findViewById(R.id.br_dessert);
        et_intitule = findViewById(R.id.et_intitule);
        et_modifier = findViewById(R.id.et_modifier);
        sp_modifEntree = findViewById(R.id.sp_modifEntree);
        sp_modifPlat = findViewById(R.id.sp_modifPlat);
        sp_modifDessert = findViewById(R.id.sp_modifDessert);
        sp_supprEntree = findViewById(R.id.sp_supprEntree);
        sp_supprPlat = findViewById(R.id.sp_supprPlat);
        sp_supprDessert = findViewById(R.id.sp_supprDessert);

        // Events
        b_retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent unIntent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(unIntent);
            }
        });

        b_ajouter.setEnabled(false);

        // Verifie si l'EditText est vide ou pas, s'il l'est, cela bloque le bouton ajouter
        et_intitule.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (et_intitule.getText().toString().trim().length() > 0) {
                    b_ajouter.setEnabled(true);
                } else {
                    b_ajouter.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        b_ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Récupération de la valeur du radio button coché
                RadioButton brSelected = findViewById(rg_types.getCheckedRadioButtonId());
                String type = brSelected.getText().toString();

                // Récupération de l'intitulé du nouveau plat
                String nvPlat = et_intitule.getText().toString().trim();

                // Ecrire le nouveau plat dans le fichier values/listebouffe.xml
                Log.d("Ajout",type + " : " + nvPlat);

                // On vide le edit text
                et_intitule.setText("");
            }
        });

        sp_supprEntree.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sp_supprPlat.setSelection(0);
                sp_supprDessert.setSelection(0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_supprPlat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sp_supprEntree.setSelection(0);
                sp_supprDessert.setSelection(0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp_supprDessert.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sp_supprEntree.setSelection(0);
                sp_supprPlat.setSelection(0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        b_supprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int indice;
                String nom;
                String libelle;
                String msg;

                if(sp_supprPlat.getSelectedItemPosition()==0 && sp_supprDessert.getSelectedItemPosition()==0) {
                    indice = sp_supprEntree.getSelectedItemPosition();
                    nom = "Entree";
                    libelle = sp_supprEntree.getSelectedItem().toString();
                }

                if(sp_supprEntree.getSelectedItemPosition()==0 && sp_supprDessert.getSelectedItemPosition()==0) {
                    indice = sp_supprPlat.getSelectedItemPosition();
                    nom = "Plat";
                    libelle = sp_supprPlat.getSelectedItem().toString();
                }

                if(sp_supprEntree.getSelectedItemPosition()==0 && sp_supprPlat.getSelectedItemPosition()==0) {
                    indice = sp_supprDessert.getSelectedItemPosition();
                    nom = "Dessert";
                    libelle = sp_supprDessert.getSelectedItem().toString();
                }

                // Affichage dans logcat
                msg = ("Indice: " + indice + ", Type plat: " + nom + ", Intitule: " + libelle);
                Log.d("Suppression", msg);
            }
        });
    }
}
