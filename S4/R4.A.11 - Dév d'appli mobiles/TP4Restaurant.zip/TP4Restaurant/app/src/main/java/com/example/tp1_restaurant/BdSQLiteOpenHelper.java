package com.example.tp1_restaurant;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class BdSQLiteOpenHelper extends SQLiteOpenHelper {

    private String table_typeplat="create table typeplat ("
            + "idTP INTEGER PRIMARY KEY,"
            + "libelleTP TEXT NOT NULL);";

    private String table_plat="create table plat ("
            + "idP INTEGER PRIMARY KEY AUTOINCREMENT,"
            + "libelleP TEXT NOT NULL,"
            + "idTP INTEGER,"
            + "foreign key (idTP) references typeplat(idTP));";

    public BdSQLiteOpenHelper(Context context, String name, CursorFactory factory, int version) {
        super(context, name, factory, version);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(table_typeplat);
        db.execSQL(table_plat);

        db.execSQL("insert into typeplat (idTP,libelleTP) values(1,'entrée');");
        db.execSQL("insert into typeplat (idTP,libelleTP) values(2,'plat');");
        db.execSQL("insert into typeplat (idTP,libelleTP) values(3,'dessert');");

        //db.execSQL("insert into plat (idP,libelleP,idTP) values(,'',);");

        db.execSQL("insert into plat (idP,libelleP,idTP) values(1,'Aucun',1);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(2,'Foie Gras fait maison',1);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(3,'Saumon fumé',1);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(4,'Salade Verte',1);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(5,'Gambas poélées',1);");

        db.execSQL("insert into plat (idP,libelleP,idTP) values(6,'Aucun',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(7,'Tournedos de boeuf rossini',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(8,'Filet de daurade',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(9,'Magret de canard',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(10,'Faux filet',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(11,'Risottos aux légumes et parmesan',2);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(12,'Lasagnes à la ratatouille sdqfqsdf',2);");

        db.execSQL("insert into plat (idP,libelleP,idTP) values(13,'Aucun',3);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(14,'Tiramisu maison',3);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(15,'Iles flottantes',3);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(16,'Crème brulée maison',3);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(17,'Salade de fruits frais',3);");
        db.execSQL("insert into plat (idP,libelleP,idTP) values(18,'Mousse au chocolat',3);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub

    }

}
