package com.example.tp1_restaurant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // Attributs
    private Spinner sp_entree;
    private Spinner sp_plat;
    private Spinner sp_dessert;
    private Spinner sp_qte;
    private Button b_gestPlats;
    private Button b_ajouter;
    private Button b_annuler;
    private Button b_enregistrer;
    private Button b_param;
    private EditText et_qte;
    private EditText et_remarques;


    private PlatDAO unPlatDAO;
    private ArrayList<Plat> lstPlats;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Accès à la liste des plats de la classe Modele
        Modele.initEntrees();
        Modele.initPlats();
        Modele.initDesserts();

        //affSpinners();

        // Récupération des attributs
        sp_entree = findViewById(R.id.sp_entree);
        sp_plat = findViewById(R.id.sp_plat);
        sp_dessert = findViewById(R.id.sp_dessert);
        sp_qte = findViewById(R.id.sp_qte);
        b_gestPlats = findViewById(R.id.b_gestPlats);
        b_ajouter = findViewById(R.id.b_ajouter);
        b_annuler = findViewById(R.id.b_annuler);
        b_enregistrer = findViewById(R.id.b_enregistrer);
        b_param = findViewById(R.id.b_param);
        et_qte = findViewById(R.id.et_qte);
        et_remarques = findViewById(R.id.et_remarques);


        // Récupération des plats dans la bd
        unPlatDAO = new PlatDAO(this);
        lstPlats = unPlatDAO.getPlats();
        affPlatsAvecBD();


        sp_qte.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                et_qte.setText(sp_qte.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        et_qte.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (et_qte.getText().toString().trim().length() > 0) {
                    sp_qte.setEnabled(false);
                } else {
                    sp_qte.setEnabled(true);
                }
            }
        });

        b_gestPlats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent unIntent = new Intent(getApplicationContext(),gestPlats.class);
                startActivity(unIntent);
            }
        });

        b_param.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent unIntent = new Intent(getApplicationContext(),ParametrageActivity.class);
                startActivity(unIntent);
            }
        });
    }

    private void affPlatsAvecBD(){
        sp_entree = findViewById(R.id.sp_entree);
        sp_plat = findViewById(R.id.sp_plat);
        sp_dessert = findViewById(R.id.sp_dessert);

        lstPlats = unPlatDAO.getPlats();

        ArrayAdapter<String> adapterSpEntree = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        ArrayAdapter<String> adapterSpPlat = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        ArrayAdapter<String> adapterSpDessert = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);

        for(int i=0;i<lstPlats.size();i++) {
            if (lstPlats.get(i).getIdTP()==1) {
                adapterSpEntree.add(lstPlats.get(i).getLibelleP());
            } else if (lstPlats.get(i).getIdTP()==2) {
                adapterSpPlat.add(lstPlats.get(i).getLibelleP());
            } else if (lstPlats.get(i).getIdTP()==3) {
                adapterSpDessert.add(lstPlats.get(i).getLibelleP());
            }
        }
        sp_entree.setAdapter(adapterSpEntree);
        sp_plat.setAdapter(adapterSpPlat);
        sp_dessert.setAdapter(adapterSpDessert);
    }

    public void affSpinners() {
        sp_entree = findViewById(R.id.sp_entree);
        sp_plat = findViewById(R.id.sp_plat);
        sp_dessert = findViewById(R.id.sp_dessert);

        ArrayAdapter<String> adapterSpEntree = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        ArrayAdapter<String> adapterSpPlat = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        ArrayAdapter<String> adapterSpDessert = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);

        for(int i=0;i<Modele.lesEntrees.size();i++) {
            adapterSpEntree.add(Modele.lesEntrees.get(i));
        }

        for(int i=0;i<Modele.lesPlats.size();i++) {
            adapterSpPlat.add(Modele.lesPlats.get(i));
        }

        for(int i=0;i<Modele.lesDesserts.size();i++) {
            adapterSpDessert.add(Modele.lesDesserts.get(i));
        }

        sp_entree.setAdapter(adapterSpEntree);
        sp_plat.setAdapter(adapterSpPlat);
        sp_dessert.setAdapter(adapterSpDessert);
    }
}
