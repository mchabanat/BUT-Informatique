package com.example.tp1_restaurant;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class gestPlats extends AppCompatActivity {
    //Attributs
    private Button b_ajouter;
    private Button b_supprimer;
    private LinearLayout ll_listeCheckbox;
    private EditText et_nouveau;

    private ArrayList<CheckBox> lstCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gest_plats);

        b_ajouter = findViewById(R.id.b_ajouter);
        b_supprimer = findViewById(R.id.b_supprimer);
        ll_listeCheckbox = findViewById(R.id.ll_listeCheckbox);
        et_nouveau = findViewById(R.id.et_nouveau);

        lstCheck = new ArrayList<CheckBox>();

        afficherChk();
    }

    public void afficherChk() {
        ll_listeCheckbox = findViewById(R.id.ll_listeCheckbox);
        ll_listeCheckbox.removeAllViews();

        for (int i=0;i<Modele.lesPlats.size();i++) {
            CheckBox uneChk = new CheckBox(this);

            uneChk.setText(Modele.lesPlats.get(i));

            lstCheck.add(uneChk);
            ll_listeCheckbox.addView(uneChk);
        }

    }
}
